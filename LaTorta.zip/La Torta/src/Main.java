import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;

public class Main extends JFrame{
	
	JButton btnUser = new JButton("User");
	JButton btnTransaction = new JButton("Transaction");
	JButton btnManage = new JButton("Manage");
	
	JLabel lblLogin = new JLabel("Login", SwingConstants.CENTER);
	JLabel lblRegisterAsk = new JLabel("Don't Have An Account?");
	JLabel lblRegister = new JLabel("Click Here To Register");
	JLabel lblUsername = new JLabel("Username", SwingConstants.LEFT);
	JLabel lblPassword = new JLabel("Password", SwingConstants.LEFT);
	JTextField tfUsername = new JTextField();
	JTextField tfPassword = new JTextField();
	
	
	Box boxMenu = Box.createHorizontalBox();

    JMenu menuLogin = new JMenu("Menu"); 
    
    JMenu menuTRX = new JMenu("Transaction");
    JMenu menuOther = new JMenu("Other");

    JMenu menuManage = new JMenu("Manage");
    
	public Main(String title) {
		// TODO Auto-generated constructor stub
		super(String.valueOf(title));
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	System.exit(0);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(1000, 600);
		setResizable(true);
		setLocationRelativeTo(null);
		
		
		initMenu(this);
		
		setLayout(new BorderLayout());

        JLabel background=new JLabel(new ImageIcon("images/bg.jpg"));

        add(background);
        background.setLayout(new FlowLayout());

		//Adding TO PANEL END
		//Harus Paling Akhir BEGIN
		setVisible(true);
		//Harus Paling Akhir END
		
	}
	
	class ImagePanel extends JPanel {

		  private Image img;

		  public ImagePanel(String img) {
		    this(new ImageIcon(img).getImage());
		  }

		  public ImagePanel(Image img) {
		    this.img = img;
		    Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
		    setPreferredSize(size);
		    setMinimumSize(size);
		    setMaximumSize(size);
		    setSize(size);
		    setLayout(null);
		  }

		  public void paintComponent(Graphics g) {
		    g.drawImage(img, 0, 0, null);
		  }

	}
	

	
	private void initMenu(Main mainclass) {
		
		JMenuBar mb = new JMenuBar();  
		
		JMenuItem itemLogout=new JMenuItem("Logout");
		itemLogout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				User.role = "";
				new Main("La Torta Shop");
				dispose();
			}
		});
		
		if(User.role.equals("admin")) {
			
			
			JMenuItem iMember=new JMenuItem("Members");  
			iMember.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					ManageMember m = new ManageMember(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});
			
			JMenuItem itemCakes=new JMenuItem("Cakes");
			itemCakes.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					ManageCake m = new ManageCake(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});


			JMenuItem itemTRX=new JMenuItem("Transcation");
			itemTRX.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					ManageTransaction m = new ManageTransaction(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});

	        menuManage.add(iMember); menuManage.add(itemCakes); menuManage.add(itemTRX); 
	        mb.add(menuManage);
	        
			
				        
	        menuOther.add(itemLogout); 
	        mb.add(menuOther);
		}else if(User.role.equals("member")){

			JMenuItem itemBuy=new JMenuItem("Buy Items");
			itemBuy.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Buy m = new Buy(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});
			
			JMenuItem itemView=new JMenuItem("View Transaction");  
			itemView.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					ViewTransaction m = new ViewTransaction(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});
		
	        menuTRX.add(itemBuy); menuTRX.add(itemView);
	        mb.add(menuTRX);
	        
			
			menuOther.add(itemLogout); 
	        mb.add(menuOther);
		}else {
			
			JMenuItem mLogin=new JMenuItem("Login");
			mLogin.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					LoginForm m = new LoginForm(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});
			
			JMenuItem mRegister=new JMenuItem("Register");
			mRegister.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Register m = new Register(mainclass);
					m.setVisible(true);
					setEnabled(false);
				}
			});
			
	        menuLogin.add(mLogin); menuLogin.add(mRegister); 
	        mb.add(menuLogin);
			
		}
        
        setJMenuBar(mb);
	}

	public static void main(String[] args) {
		new Main("La Torta Shop");
	}
	
}
