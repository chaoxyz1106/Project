import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginForm extends JFrame{
	
	public static Connection con = new Database().get_connection();
	
	JButton btnLogin = new JButton("Login");
	JButton btnRegister = new JButton("Register");
	JLabel lblLogin = new JLabel("Login", SwingConstants.CENTER);
	JLabel lblEmail = new JLabel("Email", SwingConstants.LEFT);
	JLabel lblPassword = new JLabel("Password", SwingConstants.LEFT);
	JTextField txtEmail = new JTextField(13);
	JPasswordField txtPassword = new JPasswordField(13);
	
	JPanel mainPanel = new JPanel(); 
	JPanel pEmail = new JPanel();
	JPanel pPassword = new JPanel(); 
	JPanel psEmail = new JPanel();
	JPanel psPassword = new JPanel();
	JPanel pLR = new JPanel();
	JPanel pLogin = new JPanel();
	JPanel pRegister = new JPanel();
	JCheckBox cbTerms = new JCheckBox("I Agree With Terms And Condition");

	
	private Color BGCOLOR = Color.GRAY;
	Main mainclass;
	
	
	public LoginForm(Main mainclass) {
		// TODO Auto-generated constructor stub
		super("Login");
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure to Close Application?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	mainclass.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(500, 200);
		setResizable(false);
		setLocationRelativeTo(null);
		
		lblLogin.setFont(new Font(null, Font.BOLD, 20));
		cbTerms.setFont(new Font(null, Font.PLAIN, 12));
	
		pEmail.setLayout(new GridLayout(1,2));
		psEmail.setBorder(new EmptyBorder(10, 10, 10, 10));
		psEmail.add(txtEmail);
		pEmail.add(lblEmail);
		pEmail.add(psEmail);
		
		pPassword.setLayout(new GridLayout(1,2));		
		psPassword.setBorder(new EmptyBorder(10, 10, 10, 10));
		psPassword.add(txtPassword);
		pPassword.add(lblPassword);
		pPassword.add(psPassword);	
		
		pLogin.setLayout(new FlowLayout(FlowLayout.CENTER));
		pLogin.add(btnLogin);
		
		pRegister.setLayout(new FlowLayout(FlowLayout.CENTER));
		pRegister.add(btnRegister);
		
		JPanel pTerms = new JPanel();

		pTerms.setBorder(new EmptyBorder(5, 0, 5, 0));
		pTerms.setLayout(new GridLayout(1,2));
		pTerms.add(new JLabel());
		pTerms.add(cbTerms);
		
		mainPanel.setBorder(new EmptyBorder(0, 30, 0, 30));
		mainPanel.setLayout(new GridLayout(5,1));
		mainPanel.add(lblLogin);
		mainPanel.add(pEmail);
		mainPanel.add(pPassword);
		mainPanel.add(pTerms);
		mainPanel.add(pLogin);
		add(mainPanel);

		activity(mainclass);
		
		//Harus Paling Akhir BEGIN
		setVisible(true);
		//Harus Paling Akhir END
		
	}

	private void activity(Main mainclass) {
		// TODO Auto-generated method stub
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(valid()) {
						
					PreparedStatement ps = null;
					
					try {
						ps = con.prepareStatement("SELECT * FROM member WHERE email = ? AND password = ?");
						ps.setString(1, txtEmail.getText());
						ps.setString(2, new String(txtPassword.getPassword()));
						
						ResultSet rs = ps.executeQuery();
						
						if(rs.next()) {
							User.memberid = rs.getInt("memberid");
							User.email = rs.getString("email");
							User.password = rs.getString("password");
							User.phone = rs.getString("phone");
							User.DOB = rs.getString("DOB");
							User.gender = rs.getString("gender");
							User.address = rs.getString("address");
							User.role = rs.getString("rolename");
							
							mainclass.setEnabled(true);
							new Main("Welcome, "+User.email);
							mainclass.dispose();
							dispose();
							
						}else {
							JOptionPane.showMessageDialog(null, "Data not found");
						}
						
					} catch (Exception exception) {
						System.out.println(exception);
						exception.printStackTrace();
						// TODO: handle exception
					}	
				}
			}

			private boolean valid() {
				
				boolean flagUsername = false, flagPassword = false;
				
				String text = "";
				
				if(txtEmail.getText().equals("")) {
					flagUsername = true;
					text = text + "Email ";
				}
				
				if(new String(txtPassword.getPassword()).equals("")) {
					flagPassword = true;
					if(flagUsername) {
						text = text + "and ";
					}
					text = text + "Password ";
				}
				
				
				if(flagUsername || flagPassword) {
					text = text + "must be filled";
					JOptionPane.showMessageDialog(null, text);
					return false;
				}
				
				if(!cbTerms.isSelected()) {
					text = text + "must be filled";
					JOptionPane.showMessageDialog(null, "You Must Agree With Our Terms And Condition");
					return false;
				}

				return true;
				
			}
		});
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main("La Torta Shop");
		

	}

}
