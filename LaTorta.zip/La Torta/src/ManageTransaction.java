
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;

public class ManageTransaction extends JFrame{

	public static Connection con = new Database().get_connection();
	
	JLabel lblMenu = new JLabel("Manage Transaction", SwingConstants.CENTER);
	
	JLabel lblID = new JLabel("ID", SwingConstants.LEFT);
	JLabel lblName = new JLabel("Name", SwingConstants.LEFT);
	JLabel lblDate = new JLabel("Date", SwingConstants.LEFT);
	JLabel lblEmail = new JLabel("Email", SwingConstants.LEFT);
	JLabel lblQty = new JLabel("Quantity", SwingConstants.LEFT);
	
	JTextField txtID = new JTextField();
	JTextField txtName = new JTextField();
	JTextField txtDate = new JTextField();
	JTextField txtEmail = new JTextField();
	JSpinner txtQty = new JSpinner();
	
	JButton buttonDel = new JButton("Delete");
	
	JTable table = new JTable();
	JScrollPane scrollPane = new JScrollPane();
	
	JPanel mainPanel = new JPanel();
	JPanel subPanel = new JPanel();
	JPanel pTable = new JPanel();

	
	Main mainclass;
	public ManageTransaction(Main mainclass) {
		// TODO Auto-generated constructor stub
		super("Manage Transaction");
		this.mainclass = mainclass;
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure to Close Application?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	mainclass.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(900, 420);
		setResizable(false);
		setLocationRelativeTo(null);
		
		lblMenu.setFont(new Font(null, Font.BOLD, 20));

		
		getData();
		activity();
		init();
		tableActivity();
			
		setVisible(true);
		
	}
	
	private void init() {		
		
		clr();
		
		pTable.setBorder(new EmptyBorder(0, 30, 0, 30));
		pTable.setLayout(new BorderLayout());
		lblMenu.setBorder(new EmptyBorder(10, 50, 10, 50));
		pTable.add(lblMenu, BorderLayout.NORTH);
		pTable.add(scrollPane);
		
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3,2));
		leftPanel.add(lblID); leftPanel.add(txtID);
		leftPanel.add(lblName); leftPanel.add(txtName);
		leftPanel.add(lblDate); leftPanel.add(txtDate);
		
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new GridLayout(3,2));
		rightPanel.add(new JLabel()); rightPanel.add(new JLabel());
		rightPanel.add(lblEmail); rightPanel.add(txtEmail);
		rightPanel.add(lblQty); rightPanel.add(txtQty);
		
		subPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		subPanel.setLayout(new GridLayout(1,2));
		subPanel.add(leftPanel);
		subPanel.add(rightPanel);
		
		JPanel buttonp = new JPanel();
		buttonp.add(buttonDel);
		
		JPanel mainSPanel = new JPanel();
		mainSPanel.setLayout(new BorderLayout());
		mainSPanel.add(subPanel, BorderLayout.CENTER);
		mainSPanel.add(buttonp, BorderLayout.SOUTH);
		
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(pTable);
		mainPanel.add(mainSPanel);
		add(mainPanel);
	}
	
	private void clr() {
		txtID.setEnabled(false);
		txtName.setEnabled(false);
		txtDate.setEnabled(false);
		txtEmail.setEnabled(false);
		txtQty.setEnabled(false);
		buttonDel.setEnabled(false);
		
	}

	private void getData() {
		clr();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
	
		DefaultTableModel model = new DefaultTableModel() {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		model.addColumn("Transaction ID");
		model.addColumn("Email");
		model.addColumn("Cake Name");
		model.addColumn("Quantity");
		model.addColumn("Date");
		PreparedStatement ps = null;

		try {
			System.out.println(lblMenu + "Read Database");
			ps = con.prepareStatement("Select "
					+ "t.transactionid, member.email, "
					+ "cake.cakename, "
					+ "dt.quantity, "
					+ "t.transactiondate FROM member, transaction t, detailtransaction dt, cake "
					+ "WHERE t.transactionid = dt.transactionid AND "
					+ "cake.cakeid = dt.cakeid AND "
					+ "t.memberid = member.memberid ORDER BY t.transactiondate ASC");
			
			ResultSet rs = ps.executeQuery();

			
			while(rs.next()) {			
				model.addRow(new Object[] {
						rs.getString("transactionid"),
						rs.getString("email"),
						rs.getString("cakename"),
						rs.getString("quantity"),
						rs.getString("transactiondate")
				});
//				obj = new Menu(
//						rs.getInt("id"),
//						rs.getString("name"),
//						rs.getInt("quantity"),
//						rs.getInt("price")
//				);
			}
			
			table.setModel(model);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
	
	private void activity() {
		
		buttonDel.addActionListener(new ActionListener() {
				
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				int[] selected = table.getSelectedRows();
				if(txtEmail.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select The Data First");
				}else {
					int confirm = JOptionPane.showOptionDialog(
			             null, "Are You Sure?", 
			             "Select An Option?", JOptionPane.YES_NO_OPTION, 
			             JOptionPane.QUESTION_MESSAGE, null, null, null);
			        if (confirm == 0) {
			        	
			        	PreparedStatement ps = null;
			    		
			    		try {
			    			ps = con.prepareStatement("DELETE FROM transaction WHERE transactionid = ?");
			    			ps.setString(1, (txtID.getText()));
			    			int rs = ps.executeUpdate();
			    			
			    			if(rs > 0) {
			    				JOptionPane.showMessageDialog(null, "Delete Success");
			    				getData();
			    				clr();
			    			}else {
			    				JOptionPane.showMessageDialog(null, "There is Trouble");
			    			}
			    			
			    		} catch (Exception exception) {
			    			System.out.println(exception);
			    			exception.printStackTrace();
			    			// TODO: handle exception
			    		}
			        }
				}
			}

		});		
		
		
	}

	
	private void tableActivity() {
		table.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(final MouseEvent arg0) {
				// TODO Auto-generated method stub
				String sId = table.getValueAt(table.getSelectedRow(), 0).toString();
				String sEmail = table.getValueAt(table.getSelectedRow(), 1).toString();
				String sName = table.getValueAt(table.getSelectedRow(), 2).toString();
				String sQty = table.getValueAt(table.getSelectedRow(), 3).toString();
				String sDate = table.getValueAt(table.getSelectedRow(), 4).toString();
				txtID.setText(sId);
				txtName.setText(String.valueOf(sName));	
				txtEmail.setText(String.valueOf(sEmail));
				txtDate.setText(String.valueOf(sDate));
				txtQty.setValue(Integer.parseInt(String.valueOf(sQty)));
				
				
				buttonDel.setEnabled(true);
				
			}
		});
	}
	
	
	
	
	public static void main(String[] args) {
		new Main("Welcome, "+User.email);
	}

}
