
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class ManageMember extends JFrame{

	public static Connection con = new Database().get_connection();
	
	JLabel lblMenu = new JLabel("Manage Member", SwingConstants.CENTER);
	
	JLabel lblEmail = new JLabel("Email", SwingConstants.LEFT);
	JLabel lblPassword = new JLabel("Password", SwingConstants.LEFT);
	JLabel lblPhone = new JLabel("Phone", SwingConstants.LEFT);
	JLabel lblDOB = new JLabel("DOB", SwingConstants.LEFT);
	JLabel lblGender = new JLabel("Gender", SwingConstants.LEFT);
	JLabel lblAddress = new JLabel("Address", SwingConstants.LEFT);
	
	JTextField txtEmail = new JTextField("");
	JPasswordField txtPassword = new JPasswordField("");
	JTextField txtPhone = new JTextField("");
	JTextField txtGender = new JTextField("");
	JTextField txtAddress = new JTextField("");
	
	JComboBox comboDay;
	JComboBox comboMonth;
	JComboBox comboYear;
	
	JTable table = new JTable();
	JScrollPane scrollPane = new JScrollPane();
	
	JButton btninsert = new JButton("Insert");
	JButton btnupdate = new JButton("Update");
	JButton btndelete = new JButton("Delete");
	JButton btncancel = new JButton("Cancel");
	
	
	JRadioButton radioMale = new JRadioButton("Male");
	JRadioButton radioFemale = new JRadioButton("Female");
	ButtonGroup bg = new ButtonGroup();
	
	
	JPanel mainPanel = new JPanel();
	JPanel subPanel = new JPanel();
	JPanel pTable = new JPanel();
	JPanel pButton = new JPanel();

	static String kelamin;
	
	Main activity;
	public ManageMember(Main activity) {
		// TODO Auto-generated constructor stub
		super("Manage Member");
		this.activity = activity;
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure to Close Application?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	activity.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(900, 420);
		setResizable(false);
		setLocationRelativeTo(null);

		getDate();
		lblMenu.setFont(new Font(null, Font.BOLD, 20));

		
		getData();
		activity();
		init();
		tableActivity();
		
		
		setVisible(true);
		
	}
	
	private void getDate() {
		
		Vector<String> YEAR = new Vector<>();
		YEAR.add("YEAR");
		Vector<String> MONTH = new Vector<>();
		MONTH.add("MONTH");
		Vector<String> DAY = new Vector<>();
		DAY.add("DAY");
		
		for(int i = 1990; i <= 2018; i++) {
			YEAR.add(String.valueOf(i));
		}
		
		comboYear = new JComboBox<>(YEAR);
		
		for(int i = 1; i <= 12; i++) {
			MONTH.add(String.valueOf(i));
		}
		
		comboMonth = new JComboBox<>(MONTH);
		
		for(int i = 1; i <= 31; i++) {
			DAY.add(String.valueOf(i));
		}
		
		comboDay = new JComboBox<>(DAY);
		
	}

	private void init() {		
		

		pTable.setBorder(new EmptyBorder(0, 30, 0, 30));
		pTable.setLayout(new BorderLayout());
		lblMenu.setBorder(new EmptyBorder(10, 50, 10, 50));
		pTable.add(lblMenu, BorderLayout.NORTH);
		pTable.add(scrollPane);
		
		JPanel pGender = new JPanel();
		pGender.setBorder(new EmptyBorder(5, 0, 5, 0));
		pGender.setLayout(new GridLayout(1,2));
		JPanel pG = new JPanel();
		bg.add(radioMale);
		bg.add(radioFemale);
		pG.setLayout(new GridLayout(1,2));
		pG.add(radioMale);
		pG.add(radioFemale);
		pGender.add(lblGender);
		pGender.add(pG);
		
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3,2));
		leftPanel.add(lblEmail); leftPanel.add(txtEmail);
		leftPanel.add(lblPassword); leftPanel.add(txtPassword);
		leftPanel.add(lblGender); leftPanel.add(pGender);
		
		JPanel pDOB = new JPanel();
		JPanel psDOB = new JPanel();

		pDOB.setBorder(new EmptyBorder(5, 0, 5, 0));
		pDOB.setLayout(new GridLayout(1,2));
		psDOB.setLayout(new GridLayout(1, 3));
		psDOB.add(comboDay);
		psDOB.add(comboMonth);
		psDOB.add(comboYear);
		pDOB.add(lblDOB);
		pDOB.add(psDOB);
		
		
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new GridLayout(3,2));
		rightPanel.add(lblPhone); rightPanel.add(txtPhone);
		rightPanel.add(lblDOB); rightPanel.add(pDOB);
		rightPanel.add(lblAddress); rightPanel.add(txtAddress);
	
		
		subPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		subPanel.setLayout(new GridLayout(1,2));
		subPanel.add(leftPanel);
		subPanel.add(rightPanel);
		
		pButton.setLayout(new FlowLayout(FlowLayout.CENTER));
		pButton.add(btninsert);
		pButton.add(btnupdate);
		pButton.add(btndelete);
		pButton.add(btncancel);
		
		JPanel mainSPanel = new JPanel();
		mainSPanel.setLayout(new BorderLayout());
		mainSPanel.add(subPanel, BorderLayout.CENTER);
		mainSPanel.add(pButton, BorderLayout.SOUTH);
		
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(pTable);
		mainPanel.add(mainSPanel);
		add(mainPanel);
	}
	
	private void clr() {
		txtEmail.setText(String.valueOf(""));
		txtPassword.setText(String.valueOf(""));	
		txtPhone.setText("");
//		tfDOB.setText(String.valueOf(""));
		txtGender.setText(String.valueOf(""));
		txtAddress.setText(String.valueOf(""));
		txtEmail.setEnabled(false);
		txtPassword.setEnabled(false);	
		txtPhone.setEnabled(false);
		txtGender.setEnabled(false);
		txtAddress.setEnabled(false);
		comboYear.setEnabled(false);
		comboMonth.setEnabled(false);
		comboDay.setEnabled(false);
		radioFemale.setEnabled(false);
		radioMale.setEnabled(false);
		btncancel.setEnabled(false);
		btninsert.setEnabled(true);
		btnupdate.setEnabled(true);
		btndelete.setEnabled(true);
		
	}

	private void getData() {
		clr();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
	
		DefaultTableModel model = new DefaultTableModel() {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		
		model.addColumn("Email");
		model.addColumn("Password");
		model.addColumn("Phone");
		model.addColumn("DOB");
		model.addColumn("Gender");
		model.addColumn("Address");
		PreparedStatement ps = null;

		try {
			System.out.println(lblMenu + "Read Database");
			ps = con.prepareStatement("Select * FROM member WHERE rolename != 'admin' ORDER BY memberid ASC");
			
			ResultSet rs = ps.executeQuery();
			Buy obj;
			
			while(rs.next()) {			
				model.addRow(new Object[] {
						rs.getString("email"),
						rs.getString("password"),
						rs.getString("phone"),
						rs.getString("dob"),
						rs.getString("gender"),
						rs.getString("address")
				});
//				obj = new Menu(
//						rs.getInt("id"),
//						rs.getString("name"),
//						rs.getInt("quantity"),
//						rs.getInt("price")
//				);
			}
			
			table.setModel(model);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
		
	private void activity() {
		
		btninsert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(btninsert.getText().equals("Insert")) {
					clr();
					txtEmail.setEnabled(true);
					txtPassword.setEnabled(true);	
					txtPhone.setEnabled(true);
					txtGender.setEnabled(true);
					txtAddress.setEnabled(true);
					comboYear.setEnabled(true);
					comboMonth.setEnabled(true);
					comboDay.setEnabled(true);
					radioFemale.setEnabled(true);
					radioMale.setEnabled(true);
					btncancel.setEnabled(true);
					btnupdate.setEnabled(false);
					btndelete.setEnabled(false);
					btninsert.setText("Save Insert");
						
				}else {
					
					insertData();
					
				}
			}		
		});
		
		btncancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clr();
				btninsert.setText("Insert");
				btnupdate.setText("Update");
			}
		});
		
		btnupdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(txtEmail.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select The Data First");
				}else {
					if(btnupdate.getText().equals("Update")) {
						txtEmail.setEnabled(false);
						txtPassword.setEnabled(true);	
						txtPhone.setEnabled(true);
						txtGender.setEnabled(true);
						txtAddress.setEnabled(true);
						comboYear.setEnabled(true);
						comboMonth.setEnabled(true);
						comboDay.setEnabled(true);
						radioFemale.setEnabled(true);
						radioMale.setEnabled(true);
						btncancel.setEnabled(true);
						btninsert.setEnabled(false);
						btndelete.setEnabled(false);
						btnupdate.setText("Save Update");
							
					}else {
						
						updateData();
						
					}	
				}
				
				
			}
		});
		
		btndelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(txtEmail.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select The Data First");
				}else {
					int confirm = JOptionPane.showOptionDialog(
			             null, "Are You Sure?", 
			             "Select An Option?", JOptionPane.YES_NO_OPTION, 
			             JOptionPane.QUESTION_MESSAGE, null, null, null);
			        if (confirm == 0) {
			        	
			        	PreparedStatement ps = null;
			    		
			    		try {
			    			ps = con.prepareStatement("DELETE FROM member WHERE email = ?");
			    			ps.setString(1, (txtEmail.getText()));
			    			int rs = ps.executeUpdate();
			    			
			    			if(rs > 0) {
			    				JOptionPane.showMessageDialog(null, "Delete Success");
			    				getData();
			    				clr();
			    			}else {
			    				JOptionPane.showMessageDialog(null, "There is Trouble");
			    			}
			    			
			    		} catch (Exception exception) {
			    			System.out.println(exception);
			    			exception.printStackTrace();
			    			// TODO: handle exception
			    		}
			        }
				}
			}
		});
		
	}
	
	private void updateData() {
			
		if(check()) {
			
			PreparedStatement ps = null;
			
			String YEAR = comboYear.getSelectedItem().toString();
			String MONTH = comboMonth.getSelectedItem().toString();
			String DAY = comboDay.getSelectedItem().toString();
			
			String sDate = YEAR+"-"+MONTH+"-"+DAY;
			
			try {
				ps = con.prepareStatement("UPDATE member SET "
						+ "password = ?, "
						+ "gender = ?, "
						+ "phone = ?, "
						+ "dob = ?, "
						+ "address = ? WHERE email = ?");
				ps.setString(1, new String(txtPassword.getPassword()));
				ps.setString(2, kelamin);
				ps.setString(3, txtPhone.getText());
				ps.setString(4, sDate);
				ps.setString(5, txtAddress.getText());
				ps.setString(6, txtEmail.getText());
				
				int rs = ps.executeUpdate();
				
				if(rs > 0) {
					JOptionPane.showMessageDialog(null, "Edit Success");
					clr();
					getData();
					btnupdate.setText("Update");
				}else {
					JOptionPane.showMessageDialog(null, "There is Something Wrong");
				}
				
			} catch (Exception exception) {
				System.out.println(exception);
				exception.printStackTrace();
				JOptionPane.showMessageDialog(null, String.valueOf(exception));
			}	
		}
	}

	private void insertData() {
		if(check()) {
			
			PreparedStatement ps = null;
			
			String YEAR = comboYear.getSelectedItem().toString();
			String MONTH = comboMonth.getSelectedItem().toString();
			String DAY = comboDay.getSelectedItem().toString();
			
			String sDate = YEAR+"-"+MONTH+"-"+DAY;
			
			String query = "INSERT INTO member VALUES (NULL"
					+ ",  '"+txtEmail.getText()+"'"
					+ ",  '"+new String(txtPassword.getPassword())+"'"
					+ ",  '"+txtPhone.getText()+"'"
					+ ",  '"+sDate+"'"
					+ ",  '"+kelamin+"'"
					+ ",  '"+txtAddress.getText()+"'"
					+ ",  'member')";
			System.out.println(query);

			try {
				ps = con.prepareStatement(query);
				int rs = ps.executeUpdate();
				
				if(rs > 0) {
					JOptionPane.showMessageDialog(null, "Register Success");
					clr();
					getData();
					btninsert.setText("Insert");
				}else {
					JOptionPane.showMessageDialog(null, "There is Something Wrong");
				}
				
			} catch (Exception exception) {
				System.out.println(exception);
				exception.printStackTrace();
				JOptionPane.showMessageDialog(null, String.valueOf(exception));
			}	
		}
	}

	private boolean check() {
		
		boolean tanda = false;
		String msg = "";
		
	
		if(radioMale.isSelected()) {
			kelamin = "male";
		}else if(radioFemale.isSelected()) {
			kelamin = "female";
		}else {
			tanda = true;
			msg = msg + "\n - Gender must be selected";
		}
		
		if(txtEmail.getText().equals("")) {
			tanda = true;
			msg = msg + "\n - Please Write Down Your Email!";
		}
		
		if(txtEmail.getText().startsWith("@") || txtEmail.getText().startsWith(".")) {
			tanda = true;
			msg = msg + "\n - Email Must not starts with �@� and �.�";
		}
		
		if(!txtEmail.getText().contains("@") || !txtEmail.getText().contains(".")) {
			tanda = true;
			msg = msg + "\n - Enter A Valid Email!";
		}
		
		if(txtPhone.getText().length() != 11 && txtPhone.getText().length() != 12) {
			tanda = true;
			msg = msg + "\n - Phone Number�s length must be exactly 11 or 12";
		}
		
		
		try {
			int i = Integer.parseInt(txtPhone.getText().toString().substring(0, 6));
			int b = Integer.parseInt(txtPhone.getText().toString().substring(6, txtPhone.getText().length()));
		} catch (Exception e) {
			tanda = true;
			msg = msg + "\n - Enter A Valid Phone Number";
		}
		
		if(!txtAddress.getText().endsWith("Street")) {
			tanda = true;
			msg = msg + "\n - Address must end with �Street�";
		}
		
		if(new String(txtPassword.getPassword()).length() < 6 || new String(txtPassword.getPassword()).length() > 12) {
			tanda = true;
			msg = msg + "\n - Password length must have 6 - 12 characters";
		}

		if(new String(txtPassword.getPassword()).equals("")) {
			tanda = true;
			msg = msg + "\n - Password must be filled";
		}
		
		String YEAR = comboYear.getSelectedItem().toString();
		String MONTH = comboMonth.getSelectedItem().toString();
		String DAY = comboDay.getSelectedItem().toString();
		
		if(YEAR.equals("YEAR") || MONTH.equals("MONTH") || DAY.equals("DAY")) {
			tanda = true;
			msg = msg + "\n - Insert A Valid DOB ";
		}
		
		
		if(tanda) {
			msg = "Invalid Rules " + msg;
			JOptionPane.showMessageDialog(null, msg);
			return false;
		}
		

		return true;
		
	}

	
	private void tableActivity() {
		table.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(final MouseEvent arg0) {
				// TODO Auto-generated method stub
				String sEmail = table.getValueAt(table.getSelectedRow(), 0).toString();
				String sPassword = table.getValueAt(table.getSelectedRow(), 1).toString();
				String sPhone = table.getValueAt(table.getSelectedRow(), 2).toString();
				String sDOB = table.getValueAt(table.getSelectedRow(), 3).toString();
				String sGender = table.getValueAt(table.getSelectedRow(), 4).toString();
				String sAddress = table.getValueAt(table.getSelectedRow(), 5).toString();
				txtEmail.setText(String.valueOf(sEmail));
				txtPassword.setText(String.valueOf(sPassword));	
				txtPhone.setText(sPhone);
//				tfDOB.setText(sDOB);
				String[] DATE = sDOB.split("-");
				String YEAR = DATE[0];
				String MONTH = DATE[1];
				String DAY = DATE[2];
				comboYear.setSelectedItem(YEAR);
				comboMonth.setSelectedItem(MONTH);
				comboDay.setSelectedItem(DAY);
				if(sGender.equals("male")) {
					radioMale.setSelected(true);
				}else {
					radioFemale.setSelected(true);	
				}
				txtAddress.setText(String.valueOf(sAddress));		
				
			}
		});
	}
	
	
	
	public static void main(String[] args) {
		new Main("La Torta Shop");
//		new ManageMember(null);
	}

}
