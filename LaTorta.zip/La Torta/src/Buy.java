import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Vector;

public class Buy extends JFrame{
	
	public static Connection con = new Database().get_connection();

	JLabel lblMenu = new JLabel("Buy Cake", SwingConstants.CENTER);		
	JLabel lblID = new JLabel("ID", SwingConstants.LEFT);
	JLabel lblName = new JLabel("Name", SwingConstants.LEFT);
	JLabel lblStock = new JLabel("Stock", SwingConstants.LEFT);
	JLabel lblBrand = new JLabel("Brand", SwingConstants.LEFT);
	JLabel lblPrice = new JLabel("Price", SwingConstants.LEFT);
	JLabel lblQty = new JLabel("Quantity", SwingConstants.LEFT);
	
	JTextField txtID = new JTextField("id");
	JTextField txtName = new JTextField("name");
	JTextField txtStock = new JTextField("Stock");
	JTextField txtBrand = new JTextField("Brand");
	JTextField txtPrice = new JTextField("price");
	JSpinner spinQty = new JSpinner();
	
	JButton btnBuy = new JButton("Buy");
	JButton btnCancel = new JButton("Cancel");
	
	JTable table = new JTable();
	JScrollPane scrollPane = new JScrollPane();

	JPanel mainPanel = new JPanel();
	JPanel subPanel = new JPanel();
	JPanel pTable = new JPanel();

	Main mainclass;
	
	public Buy(Main mainclass) {
		// TODO Auto-generated constructor stub
		super("Product");
		this.mainclass = mainclass;
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	mainclass.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(700, 500);
		setResizable(true);
		setLocationRelativeTo(null);
		
		
		getData();
		activity();
		init();
		tableActivity();
		
		
		
		setVisible(true);
		
	}
	
	private void init() {
		
		clear();
		
		txtID.setEnabled(false);
		txtName.setEnabled(false);
		txtStock.setEnabled(false);
		txtBrand.setEnabled(false);
		txtPrice.setEnabled(false);
		
		
		pTable.setBorder(new EmptyBorder(0, 30, 0, 30));
		pTable.setLayout(new BorderLayout());
		lblMenu.setBorder(new EmptyBorder(10, 10, 10, 10));
		pTable.add(lblMenu, BorderLayout.NORTH);
		pTable.add(scrollPane);

		JPanel leftsub = new JPanel();
		leftsub.setLayout(new GridLayout(5, 2));
		leftsub.add(lblID);
		leftsub.add(txtID);
		leftsub.add(lblName);
		leftsub.add(txtName);
		leftsub.add(lblStock);
		leftsub.add(txtStock);
		leftsub.add(new JLabel(""));
		leftsub.add(btnBuy);
		
		
		JPanel rightsub = new JPanel();
		rightsub.setLayout(new GridLayout(5, 2));
		rightsub.add(lblBrand);
		rightsub.add(txtBrand);
		rightsub.add(lblPrice);
		rightsub.add(txtPrice);
		rightsub.add(lblQty);
		rightsub.add(spinQty);
		rightsub.add(btnCancel);
		
		subPanel.setBorder(new EmptyBorder(20, 30, 20, 30));
		subPanel.setLayout(new GridLayout(1, 2));
		subPanel.add(leftsub);
		subPanel.add(rightsub);		
		
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(pTable);
		mainPanel.add(subPanel);
		add(mainPanel);
	}

	private void clear() {
		// TODO Auto-generated method stub
		txtID.setText("");
		txtName.setText("");
		txtStock.setText("");
		txtBrand.setText("");
		txtPrice.setText("");
		
		spinQty.setValue(0);
		btnCancel.setEnabled(false);
		btnBuy.setEnabled(false);
	}

	private void getData() {
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
		
		// TODO Auto-generated method stub
		DefaultTableModel model = new DefaultTableModel() {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		model.addColumn("Product ID");
		model.addColumn("Product Name");
		model.addColumn("Brand");
		model.addColumn("Stock");
		model.addColumn("Price");
		PreparedStatement ps = null;

		try {
			System.out.println(lblMenu.getText() + " : Read DB");
			ps = con.prepareStatement("Select cake.*, brand.brandname FROM cake, brand "
					+ "WHERE cake.brandid = brand.brandid AND "
					+ "cake.stock > 0");
			
			ResultSet rs = ps.executeQuery();
					
			while(rs.next()) {			
				model.addRow(new Object[] {
						rs.getString("cakeid"),
						rs.getString("cakename"),
						rs.getString("brandname"),
						rs.getString("stock"),
						rs.getString("price")
				});
			}
			
			table.setModel(model);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			// TODO: handle exception
		}
		
	}

	private void activity() {
		
		btnBuy.addActionListener(new ActionListener() {
				
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				buy();
				
			}

		});

		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clear();
			}
		});
		
	
		
	}
	
	private void tableActivity() {
		table.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(final MouseEvent arg0) {
				// TODO Auto-generated method stub
				String sId = table.getValueAt(table.getSelectedRow(), 0).toString();
				String sName = table.getValueAt(table.getSelectedRow(), 1).toString();
				txtBrand.setText(table.getValueAt(table.getSelectedRow(), 2).toString());
				txtStock.setText(table.getValueAt(table.getSelectedRow(), 3).toString());
				int sPrice = Integer.parseInt(table.getValueAt(table.getSelectedRow(), 4).toString());
				txtID.setText(sId);
				txtName.setText(sName);
				txtPrice.setText(String.valueOf(sPrice));
				btnCancel.setEnabled(true);
				btnBuy.setEnabled(true);
			
				
			}
		});
	}
	
	private void buy() {
		

		LocalDate now = LocalDate.now();
		System.out.print(String.valueOf("DATE : " + now));
		
		if(validation()) {
			
			
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement("INSERT INTO transaction VALUES (NULL, ?, ?)", ps.RETURN_GENERATED_KEYS);
				ps.setInt(1, User.memberid);
				ps.setString(2, String.valueOf(now));
				int rs = ps.executeUpdate();
				
				if(rs > 0) {
					

					try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
			            if (generatedKeys.next()) {
			            	
			            	long insertedID = (generatedKeys.getLong(1));
			            	int insertID = (int) insertedID;
			            	
			            	ps = null;
			            	ps = con.prepareStatement("INSERT INTO detailtransaction VALUES (?,?,?)");
			            	ps.setInt(1, insertID);
			            	ps.setString(2, txtID.getText().toString());
			            	ps.setString(3, spinQty.getValue().toString());
			            	
			            	
			            	
							int rss = ps.executeUpdate();
							
							if(rss > 0) {

								ps = null;
				            	ps = con.prepareStatement("UPDATE cake SET "
				            			+ "stock = stock - ? "
				            			+ "WHERE cakeID = ?");
				            	ps.setInt(1, (int) spinQty.getValue());
				            	ps.setInt(2, Integer.parseInt(txtID.getText()));
								
								int rsss = ps.executeUpdate();
								
								if(rsss > 0) {

									getData();
									JOptionPane.showMessageDialog(null, "Transaction is Finish");
									clear();
									
								}

							}			            	
			            }
			            else {
			                throw new SQLException("Creating transaction failed, no ID obtained");
			            }
			        }
				}else {
					JOptionPane.showMessageDialog(null, "Can't Regist This Item");
				}
				
			} catch (Exception exception) {
				System.out.println(exception);
				exception.printStackTrace();
				// TODO: handle exception
			}	
			
		}
		
	}

	private boolean validation() {
		
		boolean flag = false;
		
		String text = "";
		
		if(txtID.getText().equals("")) {
			flag = true;
			text = text + "Please Choose A Product";
		}		
		
		int max = Integer.parseInt(txtStock.getText());
		if((int)spinQty.getValue() < 1 || (int)spinQty.getValue() > max) {
			flag = true;
			text = text + "\n - Insert Quantity 1 Or Must Less Than Equal "+txtStock.getText();
		}

		if(flag) {
			text = text;
			JOptionPane.showMessageDialog(null, text);
			return false;
		}

		return true;
	}
	

	public static void main(String[] args) {
//		new Main("La Torta Shop");
		new Buy(null);
	}

}
