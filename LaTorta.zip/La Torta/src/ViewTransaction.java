
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;

public class ViewTransaction extends JFrame{

	public static Connection con = new Database().get_connection();
	
	JLabel lblMenu = new JLabel("My Transaction", SwingConstants.CENTER);
	
	JTable table = new JTable();
	JScrollPane scrollPane = new JScrollPane();;
	
	JPanel mainPanel = new JPanel();
	JPanel pTable = new JPanel();
	
	
	Main activity;
	public ViewTransaction(Main activity) {
		// TODO Auto-generated constructor stub
		super("My Transaction");
		this.activity = activity;
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure to Close Application?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	activity.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(900, 350);
		setResizable(false);
		setLocationRelativeTo(null);
		
		lblMenu.setFont(new Font(null, Font.BOLD, 20));

		
		getData();
		init();
		
		setVisible(true);
		
	}
	
	private void init() {			
		pTable.setBorder(new EmptyBorder(0, 20, 0, 20));
		pTable.setLayout(new BorderLayout());
		lblMenu.setBorder(new EmptyBorder(10, 20, 10, 20));
		pTable.add(lblMenu, BorderLayout.NORTH);
		pTable.add(scrollPane);
		
		
		mainPanel.setLayout(new GridLayout(1,1));
		mainPanel.add(pTable);
		add(mainPanel);
	}

	private void getData() {
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
	
		DefaultTableModel model = new DefaultTableModel() {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		model.addColumn("Cake Name");
		model.addColumn("Brand");
		model.addColumn("Date");
		model.addColumn("Quantity");
		model.addColumn("Price");
		model.addColumn("Total Price");
		PreparedStatement ps = null;

		try {
			System.out.println(lblMenu + "Read Database");
			ps = con.prepareStatement("Select member.memberid, cake.cakename,"
					+ "cake.price,"
					+ "brand.brandname,"
					+ "t.transactiondate,"
					+ "dt.quantity FROM member, cake, transaction t, "
					+ "detailtransaction dt, brand "
					+ "WHERE "
					+ "cake.brandid = brand.brandid AND "
					+ "t.transactionid = dt.transactionid AND "
					+ "cake.cakeid = dt.cakeid AND "
					+ "t.memberid = member.memberid AND "
					+ "member.memberid = ? ORDER BY t.transactionid ASC");
			ps.setInt(1, User.memberid);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {			
				model.addRow(new Object[] {
						rs.getString("cakename"),
						rs.getString("brandname"),
						rs.getString("transactiondate"),
						rs.getString("quantity"),
						rs.getString("price"),
						String.valueOf(Integer.parseInt(rs.getString("price")) * Integer.parseInt(rs.getString("quantity")))
				});
			}
			
			table.setModel(model);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		new Main("La Torta Shop");
//		new MyTRX(null);
	}

}
