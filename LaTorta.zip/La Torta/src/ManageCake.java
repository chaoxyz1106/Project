import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class ManageCake extends JFrame{

	public static Connection con = new Database().get_connection();
	
	JLabel lblMenu = new JLabel("Manage Cake", SwingConstants.CENTER);
	
	JLabel lblID = new JLabel("Product ID", SwingConstants.LEFT);
	JLabel lblName = new JLabel("Cake Name", SwingConstants.LEFT);
	JLabel lblStock = new JLabel("Stock", SwingConstants.LEFT);
	JLabel lblBrand = new JLabel("Brand", SwingConstants.LEFT);
	JLabel lblPrice = new JLabel("Price", SwingConstants.LEFT);
	
	JTextField txtID = new JTextField("");
	JTextField txtName = new JTextField("");
	JTextField txtPrice = new JTextField("");
	
	JComboBox cbBrand;
	JSpinner spinQty = new JSpinner();
	
	JTable table = new JTable();
	JScrollPane scrollPane = new JScrollPane();
	
	JButton btninsert = new JButton("Insert");
	JButton btnupdate = new JButton("Update");
	JButton btndelete = new JButton("Delete");
	JButton btncancel = new JButton("Cancel");
	
	JRadioButton radioMale = new JRadioButton("Male");
	JRadioButton radioFemale = new JRadioButton("Female");
	ButtonGroup bg = new ButtonGroup();
	
	JPanel mainPanel = new JPanel();
	JPanel subPanel = new JPanel();
	JPanel pTable = new JPanel();
	JPanel pButton = new JPanel();

	static Vector<String> brandid = new Vector<String>();
	
	Main activity;
	public ManageCake(Main activity) {
		// TODO Auto-generated constructor stub
		super("Manage Cake");
		this.activity = activity;
		WindowListener exitListener = new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		    	
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Are You Sure to Close Application?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	dispose();
		        	activity.setEnabled(true);
		        }else {
		        	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }
		    }
		};
		addWindowListener(exitListener);
		setSize(900, 420);
		setResizable(false);
		setLocationRelativeTo(null);

		getBrand();
		lblMenu.setFont(new Font(null, Font.BOLD, 20));

		
		getData();
		activity();
		init();
		tableActivity();
		
		
		setVisible(true);
		
	}
	
	private void getBrand() {
		
		Vector<String> item = new Vector<>();
		item.add("--Choose--");
		PreparedStatement ps = null;
		try {
			System.out.println(lblMenu + "Read Database");
			ps = con.prepareStatement("Select * FROM brand");
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {			
				item.add(rs.getString("brandname"));
				brandid.add(rs.getString("brandid"));
			}
			
			cbBrand = new JComboBox<>(item);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		
	}

	private void init() {	
	
		clr();

		pTable.setBorder(new EmptyBorder(0, 30, 0, 30));
		pTable.setLayout(new BorderLayout());
		lblMenu.setBorder(new EmptyBorder(10, 50, 10, 50));
		pTable.add(lblMenu, BorderLayout.NORTH);
		pTable.add(scrollPane);
		
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3,2));
		leftPanel.add(lblID); leftPanel.add(txtID);
		leftPanel.add(lblName); leftPanel.add(txtName);
		leftPanel.add(lblStock); leftPanel.add(spinQty);
		
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new GridLayout(3,2));
		rightPanel.add(new JLabel()); rightPanel.add(new JLabel());
		rightPanel.add(lblBrand); rightPanel.add(cbBrand);
		rightPanel.add(lblPrice); rightPanel.add(txtPrice);
	
		
		subPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		subPanel.setLayout(new GridLayout(1,2));
		subPanel.add(leftPanel);
		subPanel.add(rightPanel);
		
		pButton.setLayout(new FlowLayout(FlowLayout.CENTER));
		pButton.add(btninsert);
		pButton.add(btnupdate);
		pButton.add(btndelete);
		pButton.add(btncancel);
		
		JPanel mainSPanel = new JPanel();
		mainSPanel.setLayout(new BorderLayout());
		mainSPanel.add(subPanel, BorderLayout.CENTER);
		mainSPanel.add(pButton, BorderLayout.SOUTH);
		
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(pTable);
		mainPanel.add(mainSPanel);
		add(mainPanel);
	}
	
	private void clr() {
		txtID.setText(String.valueOf(""));
		txtName.setText("");
		txtPrice.setText(String.valueOf(""));
		txtID.setEnabled(false);
		txtName.setEnabled(false);
		txtPrice.setEnabled(false);
		cbBrand.setEnabled(false);
		spinQty.setValue(0);
		radioFemale.setEnabled(false);
		radioMale.setEnabled(false);
		btncancel.setEnabled(false);
		btninsert.setEnabled(true);
		btnupdate.setEnabled(true);
		btndelete.setEnabled(true);
		
	}

	private void getData() {
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
		
		// TODO Auto-generated method stub
		DefaultTableModel model = new DefaultTableModel() {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		model.addColumn("Product ID");
		model.addColumn("Product Name");
		model.addColumn("Brand");
		model.addColumn("Stock");
		model.addColumn("Price");
		PreparedStatement ps = null;

		try {
			System.out.println(lblMenu.getText() + " : Read DB");
			ps = con.prepareStatement("Select cake.*, brand.brandname FROM cake, brand "
					+ "WHERE cake.brandid = brand.brandid AND "
					+ "cake.stock > 0");
			
			ResultSet rs = ps.executeQuery();
					
			while(rs.next()) {			
				model.addRow(new Object[] {
						rs.getString("cakeid"),
						rs.getString("cakename"),
						rs.getString("brandname"),
						rs.getString("stock"),
						rs.getString("price")
				});
			}
			
			table.setModel(model);
			
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			// TODO: handle exception
		}
		
	}
		
	private void activity() {
		
		btninsert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(btninsert.getText().equals("Insert")) {
					clr();
					txtName.setEnabled(true);
					txtPrice.setEnabled(true);
					cbBrand.setEnabled(true);
					radioFemale.setEnabled(true);
					radioMale.setEnabled(true);
					btncancel.setEnabled(true);
					btnupdate.setEnabled(false);
					btndelete.setEnabled(false);
					btninsert.setText("Save Insert");
						
				}else {
					
					insertData();
					
				}
			}		
		});
		
		btncancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clr();
				btninsert.setText("Insert");
				btnupdate.setText("Update");
			}
		});
		
		btnupdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(txtID.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select The Data First");
				}else {
					if(btnupdate.getText().equals("Update")) {
						txtID.setEnabled(false);
						txtName.setEnabled(true);
						txtPrice.setEnabled(true);
						cbBrand.setEnabled(true);
						radioFemale.setEnabled(true);
						radioMale.setEnabled(true);
						btncancel.setEnabled(true);
						btninsert.setEnabled(false);
						btndelete.setEnabled(false);
						btnupdate.setText("Save Update");
							
					}else {
						
						updateData();
						
					}	
				}
				
				
			}
		});
		
		btndelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(txtID.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select The Data First");
				}else {
					int confirm = JOptionPane.showOptionDialog(
			             null, "Are You Sure?", 
			             "Select An Option?", JOptionPane.YES_NO_OPTION, 
			             JOptionPane.QUESTION_MESSAGE, null, null, null);
			        if (confirm == 0) {
			        	
			        	PreparedStatement ps = null;
			    		
			    		try {
			    			ps = con.prepareStatement("DELETE FROM cake WHERE cakeid = ?");
			    			ps.setString(1, (txtID.getText()));
			    			int rs = ps.executeUpdate();
			    			
			    			if(rs > 0) {
			    				JOptionPane.showMessageDialog(null, "Delete Success");
			    				getData();
			    				clr();
			    			}else {
			    				JOptionPane.showMessageDialog(null, "There is Trouble");
			    			}
			    			
			    		} catch (Exception exception) {
			    			System.out.println(exception);
			    			exception.printStackTrace();
			    			// TODO: handle exception
			    		}
			        }
				}
			}
		});
		
	}
	
	private void updateData() {
			
		if(check()) {
			
			PreparedStatement ps = null;
			String selectedBrand = brandid.get(cbBrand.getSelectedIndex()-1);
			
			try {
				ps = con.prepareStatement("UPDATE cake SET "
						+ "cakename = ?, "
						+ "brandid = ?, "
						+ "price = ?, "
						+ "stock = ? "
						+ "WHERE cakeid = ?");
				ps.setString(1, txtName.getText());
				ps.setString(2, selectedBrand);
				ps.setString(3, txtPrice.getText());
				ps.setString(4, spinQty.getValue().toString());
				ps.setString(5, txtID.getText());
				
				int rs = ps.executeUpdate();
				
				if(rs > 0) {
					JOptionPane.showMessageDialog(null, "Edit Success");
					clr();
					getData();
					btnupdate.setText("Update");
				}else {
					JOptionPane.showMessageDialog(null, "There is Something Wrong");
				}
				
			} catch (Exception exception) {
				System.out.println(exception);
				exception.printStackTrace();
				JOptionPane.showMessageDialog(null, String.valueOf(exception));
			}	
		}
	}

	private void insertData() {
		if(check()) {
			
			PreparedStatement ps = null;
			
			String selectedBrand = brandid.get(cbBrand.getSelectedIndex()-1);
			
			String query = "INSERT INTO cake VALUES (NULL"
					+ ",  '"+selectedBrand+"'"
					+ ",  '"+txtName.getText()+"'"
					+ ",  '"+txtPrice.getText()+"'"
					+ ",  '"+spinQty.getValue().toString()+"')";
			System.out.println(query);

			try {
				ps = con.prepareStatement(query);
				int rs = ps.executeUpdate();
				
				if(rs > 0) {
					JOptionPane.showMessageDialog(null, "Add Success");
					clr();
					getData();
					btninsert.setText("Insert");
				}else {
					JOptionPane.showMessageDialog(null, "There is Something Wrong");
				}
				
			} catch (Exception exception) {
				System.out.println(exception);
				exception.printStackTrace();
				JOptionPane.showMessageDialog(null, String.valueOf(exception));
			}	
		}
	}

	private boolean check() {
		
		boolean tanda = false;
		String msg = "";
			
		if(cbBrand.getSelectedItem().toString().equals("--Choose--")) {
			tanda = true;
			msg = msg + "\n - Please Select The Brand";	
		}
		
		if(txtName.getText().length() < 5 || txtName.getText().length() > 20) {
			tanda = true;
			msg = msg + "\n - Cake name must be between 5 � 20 characters";
		}
		
		if(txtPrice.getText().equals("")) {
			tanda = true;
			msg = msg + "\n - Please Enter A Price";
		}
		
		try {
			int i = Integer.parseInt(txtPrice.getText().toString());
			if(i < 1000) {
				tanda = true;
				msg = msg + "\n - Price must be more than 1000";		
			}
		} catch (Exception e) {
			tanda = true;
			msg = msg + "\n - Enter A Price Number (Less or Equal to 11 Digits)";
		}
		
		try {
			int i = Integer.parseInt(spinQty.getValue().toString());
			if(i < 1) {
				tanda = true;
				msg = msg + "\n - QTY must be more than 1";		
			}
		} catch (Exception e) {
			tanda = true;
			msg = msg + "\n - Enter A Valid QTY Number";
		}
		
		if(tanda) {
			msg = "Invalid Terms " + msg;
			JOptionPane.showMessageDialog(null, msg);
			return false;
		}
		

		return true;
		
	}

	
	private void tableActivity() {
		table.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(final MouseEvent arg0) {
				// TODO Auto-generated method stub
				String sID = table.getValueAt(table.getSelectedRow(), 0).toString();
				String sName = table.getValueAt(table.getSelectedRow(), 1).toString();
				String sBrand = table.getValueAt(table.getSelectedRow(), 2).toString();
				String sStock = table.getValueAt(table.getSelectedRow(), 3).toString();
				String sPrice = table.getValueAt(table.getSelectedRow(), 4).toString();
				txtID.setText(String.valueOf(sID));
				txtName.setText(sName);
				cbBrand.setSelectedItem(sBrand);
				txtPrice.setText(String.valueOf(sPrice));
				spinQty.setValue(Integer.parseInt(sStock));
				
			}
		});
	}
	
	
	
	public static void main(String[] args) {
		new Main("La Torta Shop");
//		new ManageCake(null);
	}

}
