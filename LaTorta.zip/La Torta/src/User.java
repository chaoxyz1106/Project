public class User {

	public static int memberid;
	public static String email = "";
	public static String password = "";
	public static String phone = "";
	public static String DOB = "";
	public static String gender = "";
	public static String address = "";
	public static String role = "";

}
