
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class Register extends JFrame{
	
	public static Connection con = new Database().get_connection();

	JButton btnSubmit = new JButton("Register");
	
	JLabel lblRegister = new JLabel("Register", SwingConstants.CENTER);
	JLabel lblEmail = new JLabel("Email", SwingConstants.LEFT);
	JLabel lblPassword = new JLabel("Password", SwingConstants.LEFT);
	JLabel lblPhone = new JLabel("Phone", SwingConstants.LEFT);
	JLabel lblBirthday = new JLabel("Date Of Birth", SwingConstants.LEFT);
	JLabel lblGender = new JLabel("Gender", SwingConstants.LEFT);
	JLabel lblAddress = new JLabel("Address", SwingConstants.LEFT);
	
	JTextField txtAddress = new JTextField();
	JTextField txtEmail = new JTextField();
	JPasswordField txtPassword = new JPasswordField();
	JTextField txtPhone = new JTextField();
	
	JComboBox comboDay;
	JComboBox comboMonth;
	JComboBox comboYear;
	
	
	JRadioButton rdMale = new JRadioButton("Male");
	JRadioButton rdFemale = new JRadioButton("Female");
	ButtonGroup bg = new ButtonGroup();
	
	JPanel pMain = new JPanel();
	JPanel pEmail = new JPanel();
	JPanel pPassword = new JPanel();
	JPanel pPhone = new JPanel();
	JPanel pGender = new JPanel();
	JPanel pBirthday = new JPanel();
	JPanel psBirthday = new JPanel();
	JPanel pAddress = new JPanel();
	JPanel pSubmit = new JPanel();
	
	static String kelamin;
	
	Main mainclass;
	
	public Register(Main mainclass) {
		// TODO Auto-generated constructor stub
		super("Register");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(380, 450);
		setResizable(false);
		setLocationRelativeTo(null);
		
		getDate();
		
		lblRegister.setFont(new Font(null, Font.BOLD, 20));
		
		pEmail.setBorder(new EmptyBorder(5, 0, 5, 0));
		pEmail.setLayout(new GridLayout(1,2));
		pEmail.add(lblEmail);
		pEmail.add(txtEmail);
		
		pPassword.setBorder(new EmptyBorder(5, 0, 5, 0));
		pPassword.setLayout(new GridLayout(1,2));
		pPassword.add(lblPassword);
		pPassword.add(txtPassword);
		
		pPhone.setBorder(new EmptyBorder(5, 0, 5, 0));
		pPhone.setLayout(new GridLayout(1,2));
		pPhone.add(lblPhone);
		pPhone.add(txtPhone);
		

		pBirthday.setBorder(new EmptyBorder(5, 0, 5, 0));
		pBirthday.setLayout(new GridLayout(1,2));
		psBirthday.setLayout(new GridLayout(1, 3));
		psBirthday.add(comboDay);
		psBirthday.add(comboMonth);
		psBirthday.add(comboYear);
		pBirthday.add(lblBirthday);
		pBirthday.add(psBirthday);
		
		pGender.setBorder(new EmptyBorder(5, 0, 5, 0));
		pGender.setLayout(new GridLayout(1,2));
		JPanel pG = new JPanel();
		bg.add(rdMale);
		bg.add(rdFemale);
		pG.setLayout(new GridLayout(1,2));
		pG.add(rdMale);
		pG.add(rdFemale);
		pGender.add(lblGender);
		pGender.add(pG);
		
		pAddress.setBorder(new EmptyBorder(5, 0, 5, 0));
		pAddress.setLayout(new GridLayout(1,2));
		pAddress.add(lblAddress);
		pAddress.add(txtAddress);
		
		pSubmit.setBorder(new EmptyBorder(5, 0, 5, 0));
		pSubmit.setLayout(new FlowLayout(FlowLayout.CENTER));
		pSubmit.add(btnSubmit);
		
		pMain.setBorder(new EmptyBorder(0, 10, 0, 10));
		pMain.setLayout(new GridLayout(8,1));
		pMain.add(lblRegister);
		pMain.add(pEmail);
		pMain.add(pPassword);
		pMain.add(pPhone);
		pMain.add(pBirthday);
		pMain.add(pGender);
		pMain.add(pAddress);
		pMain.add(pSubmit);
		add(pMain);

		activity(mainclass);
		
		setVisible(true);
		
	}
	
	private void getDate() {
		
		Vector<String> YEAR = new Vector<>();
		YEAR.add("YEAR");
		Vector<String> MONTH = new Vector<>();
		MONTH.add("MONTH");
		Vector<String> DAY = new Vector<>();
		DAY.add("DAY");
		
		for(int i = 1990; i <= 2018; i++) {
			YEAR.add(String.valueOf(i));
		}
		
		comboYear = new JComboBox<>(YEAR);
		
		for(int i = 1; i <= 12; i++) {
			MONTH.add(String.valueOf(i));
		}
		
		comboMonth = new JComboBox<>(MONTH);
		
		for(int i = 1; i <= 31; i++) {
			DAY.add(String.valueOf(i));
		}
		
		comboDay = new JComboBox<>(DAY);
		
	}

	private void activity(Main mainclass) {
		// TODO Auto-generated method stub
		btnSubmit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(check()) {
					
					PreparedStatement ps = null;
					
					String YEAR = comboYear.getSelectedItem().toString();
					String MONTH = comboMonth.getSelectedItem().toString();
					String DAY = comboDay.getSelectedItem().toString();
					
					String sDate = YEAR+"-"+MONTH+"-"+DAY;
					
					String query = "INSERT INTO member VALUES (NULL"
							+ ",  '"+txtEmail.getText()+"'"
							+ ",  '"+new String(txtPassword.getPassword())+"'"
							+ ",  '"+txtPhone.getText()+"'"
							+ ",  '"+sDate+"'"
							+ ",  '"+kelamin+"'"
							+ ",  '"+txtAddress.getText()+"'"
							+ ",  'member')";
					System.out.println(query);

					try {
						ps = con.prepareStatement(query);
						int rs = ps.executeUpdate();
						
						if(rs > 0) {
							JOptionPane.showMessageDialog(null, "Register Success");
							dispose();
							mainclass.setEnabled(true);;
							
						}else {
							JOptionPane.showMessageDialog(null, "There is Something Wrong");
						}
						
					} catch (Exception exception) {
						System.out.println(exception);
						exception.printStackTrace();
						JOptionPane.showMessageDialog(null, String.valueOf(exception));
					}	
				}
			}
		});
		

	}
	
	private boolean check() {
		
		boolean tanda = false;
		String msg = "";
		
	
		if(rdMale.isSelected()) {
			kelamin = "male";
		}else if(rdFemale.isSelected()) {
			kelamin = "female";
		}else {
			tanda = true;
			msg = msg + "\n - Gender must be selected";
		}
		
		if(txtEmail.getText().equals("")) {
			tanda = true;
			msg = msg + "\n - Please Write Down Your Email!";
		}
		
		if(txtEmail.getText().startsWith("@") || txtEmail.getText().startsWith(".")) {
			tanda = true;
			msg = msg + "\n - Email Must not starts with �@� and �.�";
		}
		
		if(!txtEmail.getText().contains("@") || !txtEmail.getText().contains(".")) {
			tanda = true;
			msg = msg + "\n - Enter A Valid Email!";
		}
		
		if(txtPhone.getText().length() != 11 && txtPhone.getText().length() != 12) {
			tanda = true;
			msg = msg + "\n - Phone Number�s length must be exactly 11 or 12";
		}
		
		
		try {
			int i = Integer.parseInt(txtPhone.getText().toString().substring(0, 6));
			int b = Integer.parseInt(txtPhone.getText().toString().substring(6, txtPhone.getText().length()));
		} catch (Exception e) {
			tanda = true;
			msg = msg + "\n - Enter A Valid Phone Number";
		}
		
		if(!txtAddress.getText().endsWith("Street")) {
			tanda = true;
			msg = msg + "\n - Address must end with �Street�";
		}
		
		if(new String(txtPassword.getPassword()).length() < 6 || new String(txtPassword.getPassword()).length() > 12) {
			tanda = true;
			msg = msg + "\n - Password length must have 6 - 12 characters";
		}

		if(new String(txtPassword.getPassword()).equals("")) {
			tanda = true;
			msg = msg + "\n - Password must be filled";
		}
		
		String YEAR = comboYear.getSelectedItem().toString();
		String MONTH = comboMonth.getSelectedItem().toString();
		String DAY = comboDay.getSelectedItem().toString();
		
		if(YEAR.equals("YEAR") || MONTH.equals("MONTH") || DAY.equals("DAY")) {
			tanda = true;
			msg = msg + "\n - Please Insert A Valid Date ";
		}
		
		if(tanda) {
			msg = "Invalid Rules " + msg;
			JOptionPane.showMessageDialog(null, msg);
			return false;
		}
		

		return true;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main("La Torta Shop");
		

	}

}
