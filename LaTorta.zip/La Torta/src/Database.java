
import java.sql.Connection;
import java.sql.DriverManager;

public class Database {

	public static void main(String[] args) {
		Database obj_DB_Connection = new Database();
		System.out.println(obj_DB_Connection.get_connection());
	}
	
	public Connection get_connection() {
		Connection connection = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/latorta", "root", "");
			
		}catch(Exception e) {
			System.out.println("Cant Connect To " + connection);
			System.out.println(e);
			e.printStackTrace();
		}
		
		return connection;
	}
}